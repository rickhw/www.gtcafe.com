本節奏檔為『喝咖啡 聊音樂』作者 Rick Hwang 計，僅供個人使用，非經允許，請勿任意販售、轉貼。

吉他練習的實踐原則：專心、彈好、彈滿
http://rickmidi.blogspot.com/2015/11/blog-post_28.html


喝咖啡聊音樂: http://rickmidi.blogspot.com
Rick Hwang: rick_kyhwang@hotmail.com
GTCafe Studio: http://gtcafe.com
